
<?php
print_r(".l.");
exit;

require('common.php');
require('funciones_generales.php');
session_start();

if (isset($_SESSION['codigopermiso'])) {
} else {
    echo "<script>window.location='logout.php';</script>";
    exit;
}
$codigopermisos = $_SESSION['codigopermiso'];
$codigopermisos = trim($codigopermisos);
$hoy = date("Y-m-d");

// Consulta Nombre usuario y Supervisor
$datos = 'Activo';
$ConsultaSQL = "SELECT PKPER_NCODIGO, CRE_CUSUARIO, CRE_CNOMBRE, CRE_CNOMBRE2, CRE_CAPELLIDO, CRE_CAPELLIDO2, PER_CGRUPO, PER_CNIVEL FROM u632406828_dbp_crmfuturus.TBL_RCREDENCIAL, u632406828_dbp_crmfuturus.TBL_RPERMISO WHERE PKPER_NCODIGO = " . $codigopermisos . " AND PKCRE_NCODIGO = FKPER_NCRE_NCODIGO AND PER_CESTADO = 'Activo';";
if ($ResultadoSQL = $ConexionSQL->query($ConsultaSQL)) {
    $CantidadResultados = $ResultadoSQL->num_rows;
    if ($CantidadResultados > 0) {
        while ($FilaResultado = $ResultadoSQL->fetch_assoc()) {

            $CRE_CUSUARIO = $FilaResultado['CRE_CUSUARIO'];
            $AGENTE = $FilaResultado['PKPER_NCODIGO'];
            $nombre = null;
            $nombrecompleto = null;
            $nombre = $FilaResultado['CRE_CNOMBRE'];
            if ($nombre == null || $nombre == '') {
            } else {
                $nombrecompleto = $nombre;
            }

            $nombre = null;
            $nombre = $FilaResultado['CRE_CNOMBRE2'];
            if ($nombre == null || $nombre == '') {
            } else {
                $nombrecompleto = $nombrecompleto . ' ' . $nombre;
            }

            $nombre = null;
            $nombre = $FilaResultado['CRE_CAPELLIDO'];
            if ($nombre == null || $nombre == '') {
            } else {
                $nombrecompleto = $nombrecompleto . ' ' . $nombre;
            }

            $nombre = null;
            $nombre = $FilaResultado['CRE_CAPELLIDO2'];
            if ($nombre == null || $nombre == '') {
            } else {
                $nombrecompleto = $nombrecompleto . ' ' . $nombre;
            }

            if ($nombrecompleto == null || $nombrecompleto == '') {
                $nombrecompleto = $FilaResultado['CRE_CUSUARIO'];
            } else {
            }

            $PER_CNIVEL = $FilaResultado['PER_CNIVEL'];
            $grupotrabajo = $FilaResultado['PER_CGRUPO'];
            break;
        }
        mysqli_free_result($ResultadoSQL);
    } else {
        // Sin Resultados
        mysqli_close($ConexionSQL);
        echo "<script>window.location='logout.php';</script>";
        exit;
    }
} else {
    // Error en la Consulta
    $ErrorConsulta = mysqli_error($ConexionSQL);
    mysqli_close($ConexionSQL);
    echo "<script>window.location='logout.php';</script>";
    exit;
}


//Validacion De Usuario
if ($PER_CNIVEL != 'Supervisor'){
    echo "<script>window.location='logout.php';</script>";
    exit;
}

mysqli_close($ConexionSQL);
?>
<!doctype html>
<html lang="es">

<head>
    <title> Cargue Base Principal :: Futurus </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Lucid Bootstrap 4.1.1 Admin Template">
    <meta name="author" content="WrapTheme, design by: ThemeMakker.com">
    <link rel="icon" href="../images/logo2.png" type="image/x-icon">
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/color_skins.css">
    <link rel="stylesheet" href="../css/EstilosPersonalizadosPlantilla.css">
</head>

<body class="theme-cyan">
    <div id="wrapper">
        <div id="Loading" style="margin-left: 35%">
            <img src="../images/loading.gif">
        </div>
        <div id="nav" class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="row">
                <div class="col-1 col-sm-2 col-md-2 col-lg-2 col-xl-2 d-none d-sm-none d-md-none d-lg-block"></div>
                <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 buttom-bar-line">
                    <nav>
                        <div class="row">
                            <div class="col-sm-3 col-md-3 col-lg-3 col-xl-3 d-none d-sm-none d-md-none d-lg-block">
                                <div class="navbar-brand" style="margin-top: 1%;">
                                    <a href="index.html"><img width="50%" src="../images/FUTURUS.png" alt="Lucid Logo" class="img-responsive logo"></a>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 d-block d-sm-block d-md-block d-lg-none" style="text-align: center;">
                                <div class="navbar-brand" style="margin-top: 1%;">
                                    <a href="index.html"><img width="60%" src="../images/FUTURUS.png" alt="Lucid Logo" class="img-responsive logo"></a>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6" style="text-align: center;">
                                <div class="navbar-brand" style="margin-top: 2%;">
                                    <h6 style="color: black;"><?php echo $nombrecompleto; ?></h6>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3">
                                <div class="row">
                                    <div class="col-sm-1 col-md-1 col-lg-1 col-xl-1 d-none d-sm-none d-md-none d-lg-block">
                                    </div>
                                    <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 d-none d-sm-none d-md-none d-lg-block">
                                    </div>
                                    <div class="col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2" style="text-align: center;">
                                        <div id="navbar-menu" style="padding-right: 25%;">
                                            <ul class="nav navbar-nav">
                                                <li>
                                                    <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown"><i class="icon-bulb" title="Notificaciones: <?php echo $CantidadResultados ?>" aria-expanded="false"></i><span style="background-color: #93C01F;" class="notification-dot"></span></a>
                                                    <ul style="margin-top: -100% !important; background-color: #61636294;" class="dropdown-menu user-menu menu-icon pre-scrollable">
                                                        <?php //require("Notificaciones.php") ?>
                                                    </ul> 
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2" style="text-align: center;">
                                        <div id="navbar-menu" style="padding-right: 25%;">
                                            <ul class="nav navbar-nav">
                                                <li class="dropdown">
                                                    <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown"><i class="glyphicon glyphicon-stats" title="Reportes"></i></a>
                                                    <ul style="margin-top: -100% !important; background-color: #61636294;" class="dropdown-menu user-menu menu-icon pre-scrollable">
                                                        <?php require("Reportes.php") ?>
                                                    </ul> 
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2" style="text-align: center;">
                                        <div id="navbar-menu" style="padding-right: 25%;">
                                            <ul class="nav navbar-nav">
                                                <li class="dropdown">
                                                    <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown"><i class="glyphicon glyphicon-option-vertical"></i></a>
                                                    <ul style="margin-top: -100% !important; background-color: #61636294;" class="dropdown-menu user-menu menu-icon pre-scrollable">
                                                        <?php require("navdgacion.php") ?>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 d-none d-sm-none d-md-none d-lg-block"></div>
            </div>
        </div>
        <div id="subTitle" class="row">
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8 buttom-bar-line">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12" style="text-align: center !important;">
                        <div class="navbar-brand" style="margin-top: 4%; margin-bottom: 2%;">
                            <?php
                            if (isset($_REQUEST['Archivo_Carga_Excel'])) {
                                echo '<hs>Información A Cargar</h5>';
                            } else {
                                echo '<hs>Selección De Archivo A Cargar</h5>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2"></div>
        </div>
    </div>

    <div id="main" style="margin-top: 10%;">
        <div class="row clearfix">
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2" >
            </div>
            <div class="col-lg-8 col-md-8">
                <div class="planned_task">
                    <div class="body" >
                        <?php
                            require '../vendor/autoload.php';
                            use PhpOffice\PhpSpreadsheet\IOFactory;
                            use PhpOffice\PhpSpreadsheet\Shared\Date;

                            function FechaExcelAPhp ($Celda) {
                                $ExcelNum = $Celda->getValue();
                                if ( is_null($ExcelNum) ) {
                                    return "";
                                }
                                $Timestamp = Date::excelToTimestamp($ExcelNum);
                                $FechaPhp = date('Y-m-d', $Timestamp);
                                $FechaPhp = date("Y-m-d",strtotime($FechaPhp."+ 1 days"));
                                return $FechaPhp;
                            }

                            if (isset($_REQUEST['Archivo_Carga_Excel'])) {
                                //subir el archivo al servidor
                                $nameEXCEL = $_FILES['archivo']['name'];
                                $tmpEXCEL = $_FILES['archivo']['tmp_name'];
                                $extEXCEL = pathinfo($nameEXCEL);
                                $fileName = "../xls/empleados.xls";
                                
                                if (is_uploaded_file($tmpEXCEL)) {
                                    copy($tmpEXCEL, $fileName);
                                }
                                var_dump(copy($tmpEXCEL, $fileName);)
                                exit;
                                $file = IOFactory::load($fileName);
                                $actualPage = $file->getSheet(0);
                                $amountRows = $actualPage->getHighestDataRow();
                                $amountColumn = $actualPage->getHighestColumn();

                                //Valida que la ultima columna del excel sea la "AE" si tiene más o menos no lo deja pasar
                                if(($amountColumn != 'AE')) {
                                    echo "<script> M.toast({html: 'El archivo que intenta subir es invalido'}); </script>";
                                    echo "<script> M.toast({html: 'No coinciden la cantidad de columnas!'}); </script>";
                                    echo "<script> setTimeout(() => {
                                        window.location = 'CargueCasosSAP.php'; 
                                        exit;
                                    }, 2000) </script>";
                                }
                                echo "<h6 id='MsgCargando'>Cargando . . .</h6>";
                                echo ('<a id="BtnGuardarCargueCasos" class="orange darken-4 btn left" href="CargueCasosSAP_DB.php" style="left:0;margin-left:25px; margin-bottom: 1rem; display: none">Guardar</a> 
                             <table id="InformacionACargar" class="table highlight">
                                
                                <thead>
                                    <tr>');
                                        for ($i = 1; $i <= 1; $i++) {
                                            echo ('<tr>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(1, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(2, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(3, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(4, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(5, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(6, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(7, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(8, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(9, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(10, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(11, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(12, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(13, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(14, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(15, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(16, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(17, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(18, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(19, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(20, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(21, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(22, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(23, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(24, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(25, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(26, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(27, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(28, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(29, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(30, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(31, $i) . '</th>');
                                                echo ('<th style="border: hidden; border-left-color: currentcolor; border-left-style: hidden; border-left-width: medium; border-left: solid 1px #ccc;"></th>');
                                                echo ('</tr>');
                                            }
                                            
                                            echo ('
                                            </thead>
                                            <tbody>');
                                            for ($i = 2; $i <= $amountRows; $i++) {
                                            echo ('<tr>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(1, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(2, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(3, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(4, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(5, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(6, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(7, $i) . '</th>');
                                                $FechaAviso = $actualPage->getCellByColumnAndRow(8, $i);
                                                $FechaAviso = FechaExcelAPhp($FechaAviso);
                                                echo ('<td style="border: solid 1px #ccc;">' . $FechaAviso . '</td>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(9, $i) . '</th>');
                                                $FechaCierre = $actualPage->getCellByColumnAndRow(10, $i);
                                                $FechaCierre = FechaExcelAPhp($FechaCierre);
                                                echo ('<td style="border: solid 1px #ccc;">' . $FechaCierre . '</td>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(11, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(12, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(13, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(14, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(15, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(16, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(17, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(18, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(19, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(20, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(21, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(22, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(23, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(24, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(25, $i) . '</th>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(26, $i) . '</th>');
                                                $InicioDeseado = $actualPage->getCellByColumnAndRow(27, $i);
                                                $InicioDeseado = FechaExcelAPhp($InicioDeseado);
                                                $FinDeseado = $actualPage->getCellByColumnAndRow(28, $i);
                                                $FinDeseado = FechaExcelAPhp($FinDeseado);
                                                echo ('<td style="border: solid 1px #ccc;">' . $InicioDeseado . '</td>');
                                                echo ('<td style="border: solid 1px #ccc;">' . $FinDeseado . '</td>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(29, $i) . '</th>');
                                                $ModificadoEl = $actualPage->getCellByColumnAndRow(30, $i);
                                                $ModificadoEl = FechaExcelAPhp($ModificadoEl);
                                                echo ('<td style="border: solid 1px #ccc;">' . $ModificadoEl . '</td>');
                                                echo ('<th style="border: solid 1px #ccc;">' . $actualPage->getCellByColumnAndRow(31, $i) . '</th>');
                                                echo ('<th style="border: hidden; border-left-color: currentcolor; border-left-style: hidden; border-left-width: medium; border-left: solid 1px #ccc;"></th>');
                                            echo ('</tr>');
                                        }
                                echo ('
                                    </tbody>
                                </table>
                                ');
                            } else {
                            echo ('<div class="">
                                <form action="CargueBasePrincipal.php" method="post" enctype="multipart/form-data" name="form1">
                                    <div class="row">
                                      <div class="col-lg-10 col-md-10 col-sm-10 cl-xs-10 offset-1" style="margin-top: 4%;">
                                        <div class=" input-group fileinput-new" data-provides="fileinput">
                                            <div class="form-control" data-trigger="fileinput">
                                                <i class="fa fa-file fileinput-exists"></i>
                                                <input id="archivo" type="file" accept=".csv,.xlsx,.xlm,.ods,.xlsm" required onchange="" name="archivo"></input>
                                                <span class="fileinput-filename"></span>
                                            </div>
                                            <button type="button" class="btn btn-futurus-r" id="eliminar">Eliminar</button>
                                        </div>
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12" style="text-align: center; margin-top: 5%;">
                                            <div class="custom-file">
                                                <button type="submit" id="BtnCargarArchivo" name="Archivo_Carga_Excel" class="btn btn-futurus-r">Cargar Archivo</button>
                                            </div>
                                        </div>
                                      </div>
                                    </div>
                                </form>
                                </div>');
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>                    
    <script src="../bundles/libscripts.bundle.js"></script>
    <script src="../bundles/vendorscripts.bundle.js"></script>
    <script src="../bundles/datatablescripts.bundle.js"></script>
    <script src="../vendor/jquery-datatable/buttons/dataTables.buttons.min.js"></script>
    <script src="../vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"></script>
    <script src="../vendor/jquery-datatable/buttons/buttons.colVis.min.js"></script>
    <script src="../vendor/jquery-datatable/buttons/buttons.html5.min.js"></script>
    <script src="../vendor/jquery-datatable/buttons/buttons.print.min.js"></script>
    <script src="../vendor/sweetalert/sweetalert.min.js"></script>
    <script src="../bundles/mainscripts.bundle.js"></script>
    <script src="../js/pages/tables/jquery-datatable.js"></script>
    <script>
        
        $(document).ready(function() {

            $("#Loading").hide();
            $("#seleccionar").click(function() {
                $("#file").click();
            });
            $("#eliminar").click(function() {
                $("#archivo").val("");
            });
            $(".dt-buttons").addClass("co-md-10 col-lg-10 col-xl-10 d-none d-sm-none d-md-block d-lg-block d-xl-block");
            $(".dt-buttons").attr("style", "margin-bottom: -4%; margin-left: -1.8%");
            $(".dt-buttons").append('<a id="Guardar" class="btn btn-round btn-primary" tabindex="0" aria-controls="DataTables_Table_0" href="GuardarCargue.php"><span>Guardar</span></a>');
        })

        $("#Guardar").click(function() {
            $("#Loading").show();
        })

        $("#BtnCargarArchivo").click(function() {
            let archivo = document.getElementById('archivo').value,
            extension = archivo.substring(archivo.lastIndexOf('.'),archivo.length);
            // Si la extensión obtenida no está incluida en la lista de valores
            if(document.getElementById('archivo').getAttribute('accept').split(',').indexOf(extension) < 0) {
                alert('¡Archivo inválido! No se permite la extensión: ' + extension);
                $("#archivo").text("");
                $("#archivo").val("");                       
            }
        })
        

    </script>
</body>

</html>

